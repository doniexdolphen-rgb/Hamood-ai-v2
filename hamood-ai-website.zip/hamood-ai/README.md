# Hamood AI 🇦🇪
Mobile-first AI chat website for iPhone Safari and desktop.

## Deploy with GitHub + Render
1. Create a GitHub repository and upload **all files**, preserving the `public` folder and keeping `render.yaml` at the repository root.
2. Open Render > New > Blueprint and connect the GitHub repository. Render reads `render.yaml`.
3. In the Render service environment, add `OPENAI_API_KEY` using your OpenAI Platform API key. Keep it secret; do not put it in GitHub or frontend code.
4. Deploy. Open the public `https://...onrender.com` URL assigned by Render.
5. On iPhone Safari, tap Share > Add to Home Screen.

OpenAI API usage is billed separately from ChatGPT subscriptions. The configured model must be available to your API account. Free Render instances may sleep and take time to wake. If Blueprint creation is not available, create a Render Web Service with build command `npm install` and start command `npm start`.

## Local development
Install Node.js 20+, run `npm install`, copy `.env.example` to `.env`, enter a valid key, and run `npm start`. Visit http://localhost:3000.

## Limitations and production considerations
This version supports text chat only, not live search, images, file upload, voice or shared cross-device accounts. Chat history stays in the browser's localStorage, so it is not encrypted server-side or synced. Basic in-memory per-IP rate limiting is included, but for a public site add authentication, persistent rate limiting, spending caps and abuse prevention before inviting many users. The server sends the latest chat messages to the AI API. Do not enter sensitive information.
