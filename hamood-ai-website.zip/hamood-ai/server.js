import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import { readFileSync } from 'node:fs';
const app=express();
app.disable('x-powered-by');
app.use(express.json({limit:'80kb'}));
app.use(express.static('public'));
const prompt=readFileSync(new URL('./system-prompt.txt',import.meta.url),'utf8');
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY||'missing'});
const requests=new Map();
app.post('/api/chat',async(req,res)=>{
 const ip=req.ip;const now=Date.now();const record=requests.get(ip)||{count:0,reset:now+60000};if(now>record.reset){record.count=0;record.reset=now+60000;}record.count++;requests.set(ip,record);if(record.count>20)return res.status(429).json({error:'Too many messages. Try again in a minute.'});
 const messages=req.body?.messages;
 if(!Array.isArray(messages)||messages.length<1||messages.length>30||messages.some(m=>!m||!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>6000))return res.status(400).json({error:'Invalid messages.'});
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'Server API key is not configured.'});
 try{const response=await client.chat.completions.create({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',messages:[{role:'system',content:prompt},...messages],max_tokens:1200});res.json({reply:response.choices[0]?.message?.content||'No response generated.'});}
 catch(err){console.error('AI request failed:',err.status||err.message);res.status(502).json({error:'AI service unavailable. Check your API key, credits, and model settings.'});}
});
app.listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('Hamood AI server running'));
